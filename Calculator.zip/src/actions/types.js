export const ZERO = 'zero';
export const ONE = 'one';
export const TWO = 'two';
export const THREE = 'three';
export const FOUR = 'four';
export const FIVE = 'five';
export const SIX = 'six';
export const SEVEN = 'seven';
export const EIGHT = 'eight';
export const NINE = 'nine';

export const PERIOD = '.';
export const ADDITION = '+';
export const SUBTRACTION = '-';
export const MULTIPLICATION = '*';
export const DIVISION = '/';
export const EQUALTO = '=';

export const CLEAR = 'C';
export const BACK = 'Back';
